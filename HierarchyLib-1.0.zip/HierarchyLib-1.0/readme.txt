To get started, load up data using the classes in the data namespace.  You want to load into DataItems.
After that, you want to make groups out of them.  There are two types of groups provided, and you can use the
grouper helper class to generate groups, or make your own, or inherit the class and make your own groups that way.
After that, you will use the dataview.simple.simpledataviewgenerator class to make a horserace.  The chart type
for horse race is Bubble Chart.  There are some other chart types as well but those aren't as well supported.
That will return a horse race chart, and tou can add events and manipulate as necessary.

Alternatly, you can create superclasses of the horse race classes to create your own customized one.